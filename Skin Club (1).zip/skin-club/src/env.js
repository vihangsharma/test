export const GOOGLE_MAP_API_KEY= 'AIzaSyC9jNoCkJyt1Pk6CWpQUDG8TFAkhHo6uT0'
export const BASE_URL  = 'https://api.skinclubstudios.xyz';
export const SQUAREUP_APP_ID = 'sq0idp-mcyDs5_ucVHNqliEqTUTVA';
export const SQUAREUP_LOCATION_ID = 'L5G4NDK8BTJDE';